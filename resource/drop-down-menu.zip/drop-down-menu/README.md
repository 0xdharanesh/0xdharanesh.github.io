# Drop-down menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/pGKxpO](https://codepen.io/ig_design/pen/pGKxpO).

